Y'z Shadow 1.9 : Readme_en.txt
                                                            Since: 2002-04-01
                                                      Last Change: 2002-09-30.
Introduction

  Y'z Shadow is an enhancement software which adds a shadow effect to the windows
  in pursuit of the "beauty of a shadow".
  It also allows the user the option of making menus transparent.

  This software is free.

The main features

    - Attaches a drop shadow to the windows.
    - Makes it possible to select one type of shadow effect in the active window 
      and a different one in the inactive window.
      window and inactive window.
    - The user can choose to have transparent menus. There is also the option of 
      selecting the degree of transparency in the menus.
    - Add a drop shadow to the menus.
    - Add a drop shadow to the taskbar.
    - The width, depth, etc. of the drop shadows can all be set to your liking in 
      the settings dialog.
    - It works correctly with either WindowsXP styles or classic style.
    - The user can specify application windows that you wish to exclude from having 
      the drop shadow effect.
    - The user can choose a setting that will automatically adjust your windows so 
      they do not overlap or interfere with the taskbar.
    - Available in different languages (Japanese and English).

Requirements

    OS: Windows XP Professional or Home Edition
        Please use 16 bits (65536 colors) of screen color depth or higher.

    Caution: This software does not work in Windows 95/98/Me/NT/2000.

The installation method

    Please extract the contents of the archive to a selected folder.
    (For example, C:\Program Files\YzShadow)

The uninstallation method

    Just delete the whole folder where you extracted Y'z Shadow.
    (This software does not add any keys to the registry)

Copyright/Reproduction

    The author (M.Yamaguchi) owns the full copyright to Y'z Shadow.
    I choose to allow the use, reproduction, and distribution of this software 
    in a free manner, but only under the assumption that the contents of this 
    archive are not changed or altered in any way, and it's contents are intact.
    (for any sort of reproduction please notify me first)
    The author assumes no responsibility, or gives any sort of guarantees for
    damages that may occur from using this software.

About translation and redistribution of .lang file

    - Translation should be accurate to the original.
    - Any bitmap changed in the .lang file should be accurate to the original
      bitmaps.
    - The name (title) of the .lang file has to be in English.
    - When redistributing the translated .lang file, do not include and\or
      redistribute with the original Y'z Shadow archive.
    - Do not restrict the re-translation and redistribution by others of the
      translated .lang file.

    If the above conditions are strictly observed, you may translate and
    redistribute freely and do not need the author's permission.

Downloads of the latest versions / Contact

    - Web page [Y'z@Home]
      http://www.h5.dion.ne.jp/~yzathome/

    - E-Mail: yzathome@k9.dion.ne.jp

History

    Ver.1.9 : 2002-09-30
      [Functional addition]
        - The feature for changing the color of a drop shadow has been added.
        - The feature which allows users the option of excluding the start menu
          from the transparency effect when using Windows XP styles has been
          added.

    Ver.1.8 : 2002-09-15
      [Functional addition]
        - The translator name has been added to the .lang file.
        - Information, such as a translator name, is now displayed in
          the language selection dialog.
      [Others]
        - The .lang files have now been placed in the 'Language' sub-folder.
        - Additional bug fixes.

    Ver.1.7 : 2002-09-09
      [Functional addition]
        - Available in different languages (Japanese and English).
          (Special Thanx to Marvilla. Translation, Correction cooperation.)

    Ver.1.6 : 2002-08-24
      [Functional addition]
        - Enable/Disable is chosen by left-clicking the tray icon.
      [Bug fix]
        - The bug which a window may not close by double clicking the icon 
          on the left end of a caption is corrected.
      [Others]
        - The menu and the message were made the resource file.

    Ver.1.5 : 2002-06-10
      [Functional addition]
        - Menu fade-in When it seems to have started more than 200msec, it is
          automatic and was made not to carry out menu fade-in (an option setup
          is impossible).
          (Big menus, such as a start-program menu display faster.)
        - When the taskbar is placed on the upper part of the screen, the left end,
          or the right end, the function to adjust a position automatically so that
          a window does not overlap the taskbar is added (an option setup is
          possible).
      [Bug fix]
        - A setting dialog corrects the bug which is not closed by [x].

    Ver.1.4 : 2002-05-13
      [Functional addition]
        - The function to exclude specific windows from having the shadow effect is 
          added.
      [Bug fix]
        - The bug to attach a shadow to Apple QuickTime Player is corrected.

    Ver.1.3 : 2002-04-10
      [Bug fix]
        - The fault to which a kana input becomes amusing is corrected at the time
          of ATOK use.
          (Special thanx to COCOA, Otsuka(hb), and nhoj)

    Ver.1.2 : 2002-04-05
      [Bug fix]
        - Setting - [Menu] tab - The check box [Do not attach shadow effect to
          the start menu using WindowXP style.] corrects the bug which was
          carrying out the reverse operation.
        - In a setting dialog, the bug which did not allow use of an access key, 
          a tab key, etc. is corrected.
      [Others]
        - Display timing adjustment of a shadow (the phenomenon in which a shadow
          is displayed on the place which does not have anything by timing for
          a moment is mitigated).

    Ver.1.1 : 2002-04-02
      [Bug fix]
        - The phenomenon in which the conversion candidate window of Microsoft
          IME 2002 and a same sound different word window flicker is corrected.

    Ver.1.0 : 2002-04-01
        - The formal version release.

------------------------------------------------------------------------------
                           Copyright (c) 2002. M.Yamaguchi All rights reserved.
vim:set ft=memo:
